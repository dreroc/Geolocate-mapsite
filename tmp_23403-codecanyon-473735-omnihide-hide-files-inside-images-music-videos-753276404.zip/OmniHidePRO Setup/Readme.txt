================================================================================
OmniHide PRO Readme
================================================================================

Introduction
OmhiHide PRO (OHP) is a data-hiding utility for Windows XP and above. 
OHP allows you to hide files within other files (known as mask files). The output files from the operation can be used in a normal manner.

Tested Mask Files: 
Image Files JPG and PNG.
Music Files MP3 and OGG. 
Video Files AVI and WMV.
Document Files DOC and PDF.
File to be hidden: Any format.
NOTE: The above-mentioned file-types have been tested for usage. Other file-types may work too.  

Installation
The installation is pretty simple and straightforward. Install OHP using the installer (setup.exe) that you have downloaded. It automatically installs OHP into a directory and creates necessary shortcuts and context menu associations (if selected during installation).

License
The License permits you to use OHP only on a single PC. Read 'license.txt' for more info.

IMPORTANT INFO: By installing OmniHide, you are accepting all of the 'Terms and Conditions' mentioned in the License. 

OmniHide PRO 
http://omnihide.com/
� Copyright 2010-11 OmniHide | All Rights Reserved 